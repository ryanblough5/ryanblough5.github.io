package com.example.modulefiveprojectryanblough;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Add extends AppCompatActivity {

    EditText event_name, date, time, location;

    Button confirm_button;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_event);
        event_name = (EditText) findViewById(R.id.event_name);
        date = (EditText) findViewById(R.id.date);
        time = (EditText) findViewById(R.id.time);
        location = (EditText) findViewById(R.id.location);

        confirm_button = (Button) findViewById(R.id.confirm_button);

        if (event_name.equals("") || (date.equals("") || (time.equals("") || (location.equals("")))))
            Toast.makeText(Add.this, "Verify all fields correct", Toast.LENGTH_SHORT).show();

        confirm_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
