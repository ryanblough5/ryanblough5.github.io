package com.example.modulefiveprojectryanblough;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
public class Register extends AppCompatActivity {
    EditText name, username, password, re_enter;
    Button create_account;
    LoginDatabase db;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        name = (EditText) findViewById(R.id.name);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        re_enter = (EditText) findViewById(R.id.re_enter);

        create_account = (Button) findViewById(R.id.register);

        db = new LoginDatabase(this);

        create_account.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String full_name = name.getText().toString();
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String pass_2 = re_enter.getText().toString();

                if(name.equals("") || (username.equals("") || (password.equals("") || (re_enter.equals("")))))
                    Toast.makeText(Register.this, "Verify all fields correct", Toast.LENGTH_SHORT).show();
                else{
                    if(password.equals(re_enter)){
                        Boolean checkUsername = db.checkUsername(user);
                        if(checkUsername == false) {
                            Boolean insert = db.insertData(user, pass);
                            if (insert == true) {
                                Toast.makeText(Register.this, "Successfully registered", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), Grid.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(Register.this, "User already exists", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                                Toast.makeText(Register.this, "User already exists", Toast.LENGTH_SHORT).show();
                            }
                        }
                    else{
                        Toast.makeText(Register.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        create_account.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
